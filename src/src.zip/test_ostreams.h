#pragma once

#include "descriptions.h"
#include "test_runner.h"
#include <iostream>
#include <sstream>

void TestPhoneToOstream();
void TestCompanyToOstream();
void TestDatabaseToOstream();
void TestCompanyToShort();
