#pragma once

#include "filters.h"
#include "test_runner.h"
#include "json.h"
#include "utils.h"

#include <iostream>
#include <fstream>

namespace Filters {
  void TestPhoneParsing();
  void TestFilterParsing();
} //~Filters