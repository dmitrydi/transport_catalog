
#include "tests.h"
#include <fstream>

using namespace std;

void TestTCSaveLoad() {
//  istringstream iss(ReadFileData("../test_inputs/test_tc_save_load.txt"));
//  const auto input_doc = Json::Load(iss);
//  const auto& input_map = input_doc.GetRoot().AsMap();
//  const TransportCatalog db(
//        Descriptions::ReadDescriptions(input_map.at("base_requests").AsArray()),
//        input_map.at("routing_settings").AsMap(),
//        input_map.at("render_settings").AsMap(),
//        Descriptions::ReadDatabase(input_map.at("yellow_pages").AsMap())
//    );
//  const string& file_name = input_map.at("serialization_settings").AsMap().at("file").AsString();
//  ofstream file(file_name, ios::binary);
//  file << db.Serialize();
//  file.close();
//  const auto db2 = TransportCatalog::Deserialize(ReadFileData(file_name));
//  ASSERT_EQUAL(db.GetDb().companies.size(), db2.GetDb().companies.size());
//  for (size_t i = 0; i < db.GetDb().companies.size(); ++i)
//    ASSERT(db.GetDb().companies[i] == db2.GetDb().companies[i]);
//  ASSERT_EQUAL(db.GetDb().rubrics.size(), db2.GetDb().rubrics.size());
//  for (const auto& [k,v]: db.GetDb().rubrics) {
//    ASSERT(db2.GetDb().rubrics.count(k));
//    ASSERT(db.GetDb().rubrics.at(k) == db2.GetDb().rubrics.at(k));
//  }
}

void TestIn1() {
  // creation
  istringstream iss(ReadFileData("../test_inputs/test_tc_in_1.txt"));
  const auto input_doc = Json::Load(iss);
  const auto& input_map = input_doc.GetRoot().AsMap();
  const TransportCatalog db(
        Descriptions::ReadDescriptions(input_map.at("base_requests").AsArray()),
        input_map.at("routing_settings").AsMap(),
        input_map.at("render_settings").AsMap(),
        Descriptions::ReadDatabase(input_map.at("yellow_pages").AsMap())
    );
  // serialize and restore
  const string& file_name = input_map.at("serialization_settings").AsMap().at("file").AsString();
  ofstream file(file_name, ios::binary);
  file << db.Serialize();
  file.close();
  const auto db_new = TransportCatalog::Deserialize(ReadFileData(file_name));
  // process requests
  Json::PrintValue(
    Requests::ProcessAll(db_new, input_map.at("stat_requests").AsArray()),
    cout
  );
  cout << endl;
}

void TestAll() {
  TestRunner tr;
/*
  RUN_TEST(tr, Descriptions::TestAddress);
  RUN_TEST(tr, Descriptions::TestName);
  RUN_TEST(tr, Descriptions::TestPhone);
  RUN_TEST(tr, Descriptions::TestUrl);
  RUN_TEST(tr, Descriptions::TestWorkingTime);
  RUN_TEST(tr, Descriptions::TestNearbyStop);
  RUN_TEST(tr, Descriptions::TestCompany);
  RUN_TEST(tr, Descriptions::TestRubric);
  RUN_TEST(tr, Descriptions::TestDatabase);

  RUN_TEST(tr, Filters::TestPhoneParsing);
  RUN_TEST(tr, Filters::TestFilterParsing);

  RUN_TEST(tr, Requests::TestCompanies);

  RUN_TEST(tr, MapToRubric);
  RUN_TEST(tr, NameMatch);
  RUN_TEST(tr, DoesPhoneMatch);
  RUN_TEST(tr, UrlMatch);
  RUN_TEST(tr, RubricMatch);
  RUN_TEST(tr, DoesPhoneMatch);

  RUN_TEST(tr, TestRandomInt);

  RUN_TEST(tr, Filters::TestGenerateNamesFilter);
  RUN_TEST(tr, Filters::TestGenerateUrlsFilter);
  RUN_TEST(tr, Filters::TestGenerateRubricsFilter);
  RUN_TEST(tr, Filters::TestGeneratePhonesFilter);

  RUN_TEST(tr, Descriptions::TestGenerateRubricsMap);
  RUN_TEST(tr, Descriptions::TestMakeNameFromFilter);
  RUN_TEST(tr, Descriptions::TestMakeUrlFromFilter);
  RUN_TEST(tr, Descriptions::TestMakeRubricFromFilter);
  RUN_TEST(tr, Descriptions::TestMakePhoneFromFilter);

  RUN_TEST(tr, Descriptions::TestFillNames);
  RUN_TEST(tr, Descriptions::TestFillUrls);
  RUN_TEST(tr, Descriptions::TestFillPhones);
  RUN_TEST(tr, Descriptions::TestFillRubrics);

  RUN_TEST(tr, Descriptions::TestGenerateCompany);

//  RUN_TEST(tr, TestIn1);
//  RUN_TEST(tr, TestTCSaveLoad);


  RUN_TEST(tr, TestGenerateDataset);

  RUN_TEST(tr, TestPhoneToOstream);
  RUN_TEST(tr, TestCompanyToOstream);
  */
  RUN_TEST(tr, TestDatabaseToOstream);
  RUN_TEST(tr, TestMain);

}

