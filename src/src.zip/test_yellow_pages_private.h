#pragma once

#include "yellow_pages_private.h"
#include "test_runner.h"
#include "json.h"
#include "utils.h"

#include <iostream>
#include <fstream>

void MapToRubric();
void NameMatch();
void UrlMatch();
void RubricMatch();
void DoesPhoneMatch();
void DoesPhoneMatch2();
