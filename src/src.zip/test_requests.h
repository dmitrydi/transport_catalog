#pragma once

#include "requests.h"
#include "test_runner.h"
#include "json.h"
#include "utils.h"

#include <iostream>
#include <fstream>

namespace Requests {
  void TestCompanies();
} //~Requests